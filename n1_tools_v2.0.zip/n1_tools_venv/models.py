from main import database

class Voips(database.Model):
    id = database.Column(database.Integer, primary_key=True)
    nome = database.Column(database.String, nullable=False)
    ramal = database.Column(database.Integer, nullable=False, unique=True)
    ip = database.Column(database.String, nullable=False, unique=True)
    mac_address = database.Column(database.String, nullable=False, unique=True)
    patrimonio = database.Column(database.Integer, nullable=False, unique=True)

class Scripts(database.Model):
    id = database.Column(database.Integer, primary_key=True)
    titulo = database.Column(database.String, nullable=False)
    texto = database.Column(database.Text, nullable=False)
from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField, SubmitField, TextAreaField
from wtforms.validators import DataRequired, Length, MacAddress, IPAddress, Email


class CadastroRamais(FlaskForm):
    nome = StringField("Nome do Ramal", validators=[DataRequired()])
    ramal = IntegerField("Ramal", validators=[DataRequired(), Length(4)])
    ip = StringField("IP", validators=[DataRequired(), IPAddress(),])
    mac_address = StringField("Endereço MAC", validators=[DataRequired(), MacAddress()])
    patrimonio = IntegerField("Patrimônio", validators=[DataRequired(), Length(9)])
    btn_cadastrar = SubmitField("Cadastrar")

class Feedback(FlaskForm):
    email = StringField("E-mail", validators=[DataRequired(), Email()])
    corpo_email = TextAreaField("Mensagem", validators=[DataRequired(), Length(50, 1000)])
    btn_enviar = SubmitField("Enviar")
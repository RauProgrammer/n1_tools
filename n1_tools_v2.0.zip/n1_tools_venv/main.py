from flask import Flask, render_template, url_for
from flask_sqlalchemy import SQLAlchemy

from forms import CadastroRamais, Feedback

app = Flask(__name__)

app.config['SECRET_KEY'] = '33b4d8dcd397dd4af1571fb2f5ba06d0'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///ramais.db'

database = SQLAlchemy(app)

@app.route('/')
def homepage():
    return render_template('homepage.html')

@app.route('/scripts')
def scripts():
    return render_template('scripts.html')

@app.route('/lista-ramais')
def ramais():
    return render_template('ramais.html')

@app.route('/fluxo-chamados')
def fluxo():
    return render_template('fluxo_chamados.html')

@app.route('/documentacao')
def documentacao():
    return render_template('documentacao.html')

@app.route('/cadastrar-ramal')
def cadastrar_ramal():
    form_ramal = CadastroRamais()
    return render_template('cadastrar_ramal.html', form_ramal=form_ramal)

@app.route('/feedback-form')
def feedback():
    form_feedback = Feedback()
    return render_template('feedback_form.html', form_feedback=form_feedback)

if __name__ == '__main__':
    app.run(debug=True)